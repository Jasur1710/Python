class Menu:
    def __init__(self):
        self.items = {}
        self.max_items = 10

    def add_item(self, name, price, description=''):
        if len(self.items) < self.max_items:
            self.items[name] = {'price': price, 'description': description}
        else:
            print("Cannot add more items, menu is full.")

    def update_item(self, name, price, description):
        if name in self.items:
            self.items[name] = {'price': price, 'description': description}
        else:
            print(f"Item {name} not found in the menu.")

    def remove_item(self, name):
        if name in self.items:
            del self.items[name]
        else:
            print(f"Item {name} not found in the menu.")

    def print_menu(self):
        for idx, (name, details) in enumerate(self.items.items(), start=1):
            print(f"{idx}. {name}: ${details['price']}, Description: {details['description']}")

class Reservation:
    def __init__(self, customer_name, date, time, guests, menu):
        self.customer_name = customer_name
        self.date = date
        self.time = time
        self.guests = guests
        self.menu = menu
        self.meals = {}

    def add_meal(self, meal_name, quantity):
        if meal_name in self.menu.items:
            if meal_name in self.meals:
                self.meals[meal_name]['quantity'] += quantity
            else:
                self.meals[meal_name] = {'price': self.menu.items[meal_name]['price'], 'quantity': quantity}
        else:
            print(f"Meal {meal_name} not found in the menu.")

    def calculate_total(self):
        return sum(details['price'] * details['quantity'] for meal, details in self.meals.items())

    def __str__(self):
        reservation_details = f"Reservation for {self.customer_name} on {self.date} at {self.time} for {self.guests} guests\n"
        for meal, details in self.meals.items():
            reservation_details += f"{meal}: ${details['price']:.2f} x {details['quantity']} = ${details['price'] * details['quantity']:.2f}\n"
        reservation_details += f"Total: ${self.calculate_total():.2f}"
        return reservation_details

def display_menu(menu):
    print("\nMenu:")
    menu.print_menu()

def get_meal_by_number(menu, number):
    meal_names = list(menu.items.keys())
    if 0 < number <= len(meal_names):
        return meal_names[number - 1]
    return None


def modify_reservation_details(reservation, menu):
    print("\nModifying Reservation:")
    print(reservation)
    print("1. Change Date")
    print("2. Change Time")
    print("3. Change Number of Guests")
    print("4. Modify Meal Choices")
    print("5. Return to Previous Menu")
    choice = input("Enter your choice: ")

    if choice == '1':
        new_date = input("Enter new date (YYYY-MM-DD): ")
        reservation.date = new_date
    elif choice == '2':
        new_time = input("Enter new time (HH:MM): ")
        reservation.time = new_time
    elif choice == '3':
        new_guests = int(input("Enter new number of guests: "))
        reservation.guests = new_guests
    elif choice == '4':
        reservation.meals.clear()
        add_meal_to_reservation(reservation)
        while not review_order(reservation):
            pass
    elif choice == '5':
        return
    else:
        print("Invalid choice.")

def modify_reservation(reservations, menu):
    if reservations:
        reservation_number = int(input("Enter the number of the reservation to modify: "))
        if 0 < reservation_number <= len(reservations):
            modify_reservation_details(reservations[reservation_number - 1], menu)
        else:
            print("Invalid reservation number.")
    else:
        print("No reservations to modify.")

# ... [rest of the script]


def add_meal_to_reservation(reservation):
    display_menu(reservation.menu)
    try:
        meal_number = int(input("Enter the number of the meal to add: "))
        meal_name = get_meal_by_number(reservation.menu, meal_number)
        if meal_name:
            quantity = int(input(f"Enter quantity for {meal_name}: "))
            reservation.add_meal(meal_name, quantity)
            print(f"Added {quantity} x {meal_name}.")
        else:
            print("Invalid meal number. Please try again.")
    except ValueError:
        print("Please enter a valid number.")

def remove_meal_from_reservation(reservation):
    if reservation.meals:
        try:
            meal_number = int(input("Enter the number of the meal to remove: "))
            meal_name = get_meal_by_number(reservation.menu, meal_number)
            if meal_name and meal_name in reservation.meals:
                del reservation.meals[meal_name]
                print(f"Removed {meal_name}.")
            else:
                print("Invalid meal number. Please try again.")
        except ValueError:
            print("Please enter a valid number.")
    else:
        print("Your order is currently empty.")

def review_order(reservation):
    print("\nCurrent Order:")
    print(reservation)
    while True:
        choice = input("Do you want to (a)dd more, (r)emove a meal, or (c)onfirm this order? (a/r/c): ").lower()
        if choice == 'a':
            add_meal_to_reservation(reservation)
        elif choice == 'r':
            remove_meal_from_reservation(reservation)
        elif choice == 'c':
            return True
        else:
            print("Invalid choice. Please enter 'a', 'r', or 'c'.")

def handle_reservation(menu):
    print("\nMake a Reservation")
    name = input("Enter your name: ")
    date = input("Enter date (YYYY-MM-DD): ")
    time = input("Enter time (HH:MM): ")
    guests = int(input("Enter number of guests: "))
    reservation = Reservation(name, date, time, guests, menu)

    print("Please select your meals from the menu:")
    display_menu(menu)
    add_meal_to_reservation(reservation)
    while not review_order(reservation):
        pass
    return reservation

def admin_login():
    username = input("Enter admin username: ")
    password = input("Enter admin password: ")
    return username == "admin" and password == "adminpas"

def admin_panel(menu, reservations):
    while True:
        print("\nAdmin Panel")
        print("1. Add Menu Item")
        print("2. Update Menu Item")
        print("3. Remove Menu Item")
        print("4. View Menu")
        print("5. View All Reservations")
        print("6. Cancel a Reservation")
        print("7. Modify a Reservation")
        print("8. Logout")
        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter meal name: ")
            price = float(input("Enter price: "))
            description = input("Enter description: ")
            menu.add_item(name, price, description)
        elif choice == '2':
            name = input("Enter meal name to update: ")
            price = float(input("Enter new price: "))
            description = input("Enter new description: ")
            menu.update_item(name, price, description)
        elif choice == '3':
            name = input("Enter meal name to remove: ")
            menu.remove_item(name)
        elif choice == '4':
            display_menu(menu)
        elif choice == '5':
            for idx, reservation in enumerate(reservations, 1):
                print(f"Reservation {idx}:")
                print(reservation)
        elif choice == '6':
            if reservations:
                reservation_number = int(input("Enter the number of the reservation to cancel: "))
                if 0 < reservation_number <= len(reservations):
                    del reservations[reservation_number - 1]
                    print("Reservation cancelled.")
                else:
                    print("Invalid reservation number.")
            else:
                print("No reservations to cancel.")
        elif choice == '7':
            modify_reservation(reservations, menu)
        elif choice == '8':
            print("Logging out from admin panel.")
            break
        else:
            print("Invalid choice. Please try again.")

def user_panel(menu, reservations):
    while True:
        print("\nUser Panel")
        print("1. View Menu")
        print("2. Make a Reservation")
        print("3. View Your Reservations")
        print("4. Logout")
        choice = input("Enter your choice: ")

        if choice == '1':
            display_menu(menu)
        elif choice == '2':
            reservation = handle_reservation(menu)
            reservations.append(reservation)
        elif choice == '3':
            for reservation in reservations:
                print(reservation)
        elif choice == '4':
            print("Logging out from user panel.")
            break
        else:
            print("Invalid choice. Please try again.")

def main_menu():
    global menu, reservations
    while True:
        user_type = input("\nAre you an admin or a user? (admin/user/exit): ").lower()
        if user_type == "admin":
            if admin_login():
                admin_panel(menu, reservations)
            else:
                print("Incorrect admin credentials.")
        elif user_type == "user":
            user_panel(menu, reservations)
        elif user_type == "exit":
            print("Exiting the system. Goodbye!")
            break
        else:
            print("Invalid option. Please enter 'admin', 'user', or 'exit'.")

menu = Menu()
# Sample menu items
menu.add_item('Pizza', 9.99, 'Cheese Pizza')
menu.add_item('Burger', 8.99, 'Beef Burger with Fries')
menu.add_item('Pasta', 10.99, 'Spaghetti Carbonara')
# ... additional menu items as needed

reservations = []

if __name__ == "__main__":
    main_menu()




